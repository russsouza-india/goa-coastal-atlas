# Goa Coastal Atlas PWA

A first working student-facing Progressive Web App for exploring 50 named coastal locations in Goa.

## Run locally
Because the app uses a service worker, run it through a local web server rather than opening `index.html` as a file.
- Python: `python -m http.server 8000`
- Open `http://localhost:8000`

## Publish free with GitHub Pages
1. Create a GitHub repository (for example `goa-coastal-atlas`).
2. Upload all files in this folder to the repository root.
3. In repository Settings → Pages, choose Deploy from a branch.
4. Select `main` and `/ (root)`, then Save.
5. GitHub will provide a public URL. Share it with students or make a QR code.

Alternative: drag this folder into Netlify Drop at https://app.netlify.com/drop.

## Map and location notes
- The interactive base map uses OpenStreetMap tiles (attribution is shown in the app).
- Each beach card includes a Google Maps search link.
- Marker coordinates are approximate educational locators, not surveyed coordinates. Review and adjust all markers before public release, especially beaches with ambiguous names and adjoining stretches.
- The app is not an official inventory, navigation/safety tool, or conservation permission guide.
- The map tiles and Google Maps links require internet access. The app shell is cached for repeat visits; full offline maps are not included.
- If you create and publish a Google My Maps map, it can be embedded as a separate map view in a future revision. A custom Google My Maps embed requires its published map URL; this version avoids requiring a Google Maps API key.


## Expanded beach information panels
Each of the 50 records now includes a geographical setting, landform theme, human-geography observation, fieldwork question, map link and photo discovery links. Three individual photographs are linked from specific Government of Goa beach pages (Morjim, Agonda and Palolem). The other 47 locations show direct searches in Wikimedia Commons and Google Images rather than presenting an unrelated or AI-generated image as an authentic photograph. Before embedding any selected image, check its licence, photographer attribution, location accuracy and permission. The Government of Goa's general beach page and official ecological studies are linked in the project references.

## Research references used in the learning notes
- Government of Goa, Beaches: https://www.goa.gov.in/what_to_see/beaches/
- Government of Goa, Morjim Beach: https://www.goa.gov.in/places/morjim/
- Government of Goa, Agonda Beach: https://www.goa.gov.in/places/agonda-beach/
- Government of Goa, Palolem Beach: https://www.goa.gov.in/places/palolem-beach/
- Goa Forest Department / Goa University, *Conservation and management of mangroves and intertidal mudflats along the coastline of Goa, India* (2023 report): https://forest.goa.gov.in/sites/default/files/2024-04/Conservtion%20and%20management%20of%20mangroves_0.pdf
- Department of Information and Publicity, Government of Goa, Physiography: https://dip.goa.gov.in/physiography/
- Space Applications Centre, ISRO, *Shoreline Change Atlas of the Indian Coast* (Maharashtra & Goa volume): https://www.sac.gov.in/data/Publication/94/Volume-2_%28Maharashtra_Goa%29_2014.pdf

The descriptions are educational summaries, not a substitute for a site survey. Some locally named beach sections overlap or are used differently by residents and map services. Please validate the final list and marker coordinates with local sources before formal institutional release.


## Photographs and attribution
The beach panels now display Wikimedia Commons photographs where an exact, beach-named file was identified (30 of the 50 entries). The image credit opens the original Commons file page, which records the photographer and the applicable licence/attribution terms. For the remaining entries, the panel links directly to a beach-specific Commons MediaSearch rather than substituting an unrelated beach image.

The images are served from Wikimedia Commons, not copied into this ZIP. This keeps the package lighter and directs students to the source/credit record. An internet connection is needed to load photographs. Before reusing any image in a printed or redistributed resource, read its individual file page and comply with its specific licence (including attribution and share-alike requirements where applicable).


## Photographic attribution correction
The photo panels distinguish between:
- Images whose author and Creative Commons licence were checked against the individual Commons file page (visible author/licence labels).
- Earlier candidate Commons file links whose author/licence metadata still needs manual review (the panel links to the original record and does not present a generic author credit).
- Locations without a verified beach-specific image (no unrelated beach photo is substituted).

The file `photo_credits_register.csv` lists all 50 locations and their current photo/attribution status. For verified images, author, licence and original file page are recorded. Preserve attribution and licence links when adapting the resource. CC BY-SA material must be reused in accordance with its ShareAlike terms.
