const CACHE='goa-coastal-atlas-v3';
const SHELL=['./','./index.html','./styles.css','./app.js','./beaches.js','./manifest.webmanifest','./icon.svg'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',event=>{
 const req=event.request;
 if(req.method!=='GET')return;
 const url=new URL(req.url);
 if(url.origin===location.origin){
   event.respondWith(caches.match(req).then(cached=>cached||fetch(req).then(res=>{
     const copy=res.clone();caches.open(CACHE).then(c=>c.put(req,copy));return res;
   }).catch(()=>caches.match('./index.html'))));
 }
});