const regionOrder = ["North Goa","Central Goa","South Goa"];
let activeRegion = "All", visibleBeaches = [...window.BEACHES], selectedIndex = 0, selectedBeach = window.BEACHES[0];
const map = L.map('map', {scrollWheelZoom:false}).setView([15.32,73.87], 9);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom:19, attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);
const markerLayer = L.featureGroup().addTo(map);
const markerById = new Map();
const regionClass = r => r==="North Goa"?"north":r==="Central Goa"?"central":"south";
function selectBeach(beach, pan=true){
  selectedBeach = beach;
  const index = window.BEACHES.findIndex(b=>b.id===beach.id);
  selectedIndex = index;
  document.getElementById('regionPill').className = 'pill '+regionClass(beach.region);
  document.getElementById('regionPill').textContent = beach.region.toUpperCase();
  const photoBlock = beach.photoUrl
    ? `<figure class="photo-frame"><img src="${beach.photoUrl}" alt="${beach.name} – photograph by ${beach.photoAuthor || 'Wikimedia Commons contributor'}" loading="lazy" onerror="this.parentElement.classList.add('photo-missing');this.remove()"><figcaption class="photo-caption"><strong>${beach.photoCredit || 'Wikimedia Commons source image'}</strong><span>${beach.photoDate || ''}</span><a href="${beach.photoSource}" target="_blank" rel="noopener">Original file record ↗</a>${beach.photoLicenseUrl ? `<a href="${beach.photoLicenseUrl}" target="_blank" rel="noopener">Licence details ↗</a>` : `<small>Check the original file record for author and licence before reuse.</small>`}</figcaption></figure><div class="photo-links compact"><a href="${beach.photoSearch}" target="_blank" rel="noopener">More photographs of this beach ↗</a></div>`
    : `<div class="photo-placeholder"><span class="photo-symbol">⌁</span><strong>No verified beach photograph embedded yet</strong><small>${beach.photoAttributionStatus || beach.photoStatus || 'Photograph selection pending.'}</small><div class="photo-links"><a href="${beach.photoSearch}" target="_blank" rel="noopener">Search Wikimedia Commons ↗</a><a href="${beach.googleImages}" target="_blank" rel="noopener">Other image results ↗</a></div></div>`;
  document.getElementById('detailContent').innerHTML = `
    <div class="detail-number">${String(beach.id).padStart(2,'0')} / ${window.BEACHES.length}</div>
    <h2>${beach.name}</h2>
    <div class="panel-meta"><span>${beach.region}</span><span>Taluka: ${beach.taluka}</span><span>${beach.landform}</span></div>
    ${photoBlock}
    <section class="info-block"><span class="info-label">GEOGRAPHICAL SETTING</span><p>${beach.geography}</p></section>
    <section class="info-block"><span class="info-label">WHAT TO OBSERVE</span><p>${beach.humanGeography}</p></section>
    <section class="field-question"><span class="info-label">FIELDWORK QUESTION</span><p>${beach.fieldQuestion}</p></section>
    <div class="detail-theme">LEARNING THEME · ${beach.theme}</div>
    <div class="source-row"><a href="${beach.officialSource}" target="_blank" rel="noopener">Goa Government beach reference ↗</a></div>`;
  document.getElementById('googleLink').href = beach.googleMaps;
  document.getElementById('prevBtn').disabled = index===0;
  document.getElementById('nextBtn').disabled = index===window.BEACHES.length-1;
  document.querySelectorAll('.journey-card').forEach(c=>c.classList.toggle('selected',c.dataset.region===beach.region));
  if(pan) map.setView([beach.lat,beach.lng], Math.max(map.getZoom(),11), {animate:true});
  const marker = markerById.get(beach.id);
  if(marker) marker.openPopup();
}
function renderMarkers(){
  markerLayer.clearLayers(); markerById.clear();
  visibleBeaches.forEach(b=>{
    const cls=regionClass(b.region);
    const icon=L.divIcon({className:'',html:`<div class="beach-dot ${cls}"></div>`,iconSize:[18,18],iconAnchor:[9,9]});
    const marker=L.marker([b.lat,b.lng],{icon}).bindPopup(`<strong>${b.name}</strong><br>${b.region}<br><button onclick="window.chooseBeach(${b.id})">Explore this beach</button>`);
    marker.addTo(markerLayer); markerById.set(b.id,marker);
  });
  if(visibleBeaches.length) map.fitBounds(markerLayer.getBounds().pad(.08));
  else map.setView([15.3,73.9],9);
}
window.chooseBeach = id => {const b=window.BEACHES.find(x=>x.id===id); if(b) selectBeach(b,false);};
function applyFilters(){
  const q=document.getElementById('searchInput').value.trim().toLowerCase();
  visibleBeaches=window.BEACHES.filter(b=>(activeRegion==="All"||b.region===activeRegion)&&(!q||[b.name,b.region,b.description,b.theme].join(' ').toLowerCase().includes(q)));
  renderMarkers();
}
document.querySelectorAll('.region-tab').forEach(btn=>btn.addEventListener('click',()=>{
  activeRegion=btn.dataset.region;
  document.querySelectorAll('.region-tab').forEach(x=>x.classList.toggle('active',x===btn));
  applyFilters();
  if(visibleBeaches.length) selectBeach(visibleBeaches[0],false);
}));
document.getElementById('searchInput').addEventListener('input',()=>{
  applyFilters(); if(visibleBeaches.length) selectBeach(visibleBeaches[0],false);
});
document.getElementById('prevBtn').addEventListener('click',()=>{if(selectedIndex>0)selectBeach(window.BEACHES[selectedIndex-1]);});
document.getElementById('nextBtn').addEventListener('click',()=>{if(selectedIndex<window.BEACHES.length-1)selectBeach(window.BEACHES[selectedIndex+1]);});
const summaries={
 "North Goa":"Explore the northern coast from the Tiracol area through Pernem and Bardez, noticing river mouths, rocky coves, headlands and busy tourism belts.",
 "Central Goa":"Explore the Panaji and Mormugao coastal pocket, including the Mandovi estuary, bays, urban shorelines and the approaches to Zuari waters.",
 "South Goa":"Follow the Salcete and Canacona coast, comparing long sandy beaches, river mouths, lagoons, fishing places and sensitive nesting habitats."
};
document.getElementById('journeyCards').innerHTML=regionOrder.map(r=>{
 const count=window.BEACHES.filter(b=>b.region===r).length;
 return `<button class="journey-card" data-region="${r}"><span class="circuit">${r.toUpperCase()} CIRCUIT</span><h3>${r}</h3><p>${summaries[r]}</p><strong>${count} LOCATIONS · EXPLORE →</strong></button>`;
}).join('');
document.querySelectorAll('.journey-card').forEach(card=>card.addEventListener('click',()=>{
 activeRegion=card.dataset.region;
 document.querySelectorAll('.region-tab').forEach(x=>x.classList.toggle('active',x.dataset.region===activeRegion));
 applyFilters(); if(visibleBeaches.length)selectBeach(visibleBeaches[0]);
 document.querySelector('.workspace').scrollIntoView({behavior:'smooth'});
}));
document.getElementById('beachCount').textContent=window.BEACHES.length;
document.getElementById('aboutBtn').addEventListener('click',()=>document.getElementById('aboutDialog').showModal());
document.getElementById('closeAbout').addEventListener('click',()=>document.getElementById('aboutDialog').close());
document.querySelectorAll('.quiz-options button').forEach(btn=>btn.addEventListener('click',()=>{
 const correct=btn.dataset.answer==="Morjim Beach";
 document.querySelectorAll('.quiz-options button').forEach(x=>x.classList.remove('correct','incorrect'));
 btn.classList.add(correct?'correct':'incorrect');
 document.getElementById('quizFeedback').textContent=correct?"Correct! Morjim is known as an Olive Ridley turtle nesting beach.":"Not quite. Think of the beach in Pernem known for turtle nesting.";
}));
renderMarkers(); selectBeach(window.BEACHES[0],false);
if('serviceWorker' in navigator && location.protocol.startsWith('http')) window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
let installPrompt=null;
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;const btn=document.getElementById('installBtn');btn.hidden=false;btn.addEventListener('click',async()=>{installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;btn.hidden=true;});});
